Pokémon Essentials is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
https://creativecommons.org/licenses/by-nc-sa/4.0/

This repository is only a mirror of the original source code, found at http://pokemonessentials.wikia.com

The main goal of this repository is being able to track changes between different versions and to create
proper semver tags out of them.
